# Task 2 – UI/UX Design & Implementation 🚀

This repository contains the UI/UX components for my Task 2 submission of the **ApexPlanet Android Internship**.

## 📱 Features
- **Login Screen** with Email & Password input
- **Home Screen** with welcome message
- Clean layout using **ConstraintLayout**
- Material styling and responsive design

## 🛠️ Tech Stack
- Android Studio
- Java
- XML Layouts
- Material Components

## 📎 Links
🔗 LinkedIn Post: [Insert your LinkedIn post link here]  
📂 GitHub Repository: This repo!

## 🙌 Internship Details
**Program:** ApexPlanet 45-Day Android Internship  
**Company:** ApexPlanet Software Pvt. Ltd.  
**Task:** Task 2 – UI/UX Design  
**Duration:** Days 10–18
